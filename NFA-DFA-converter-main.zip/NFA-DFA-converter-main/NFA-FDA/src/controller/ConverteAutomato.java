package controller;

import model.Automato;

public class ConverteAutomato {
    static public Automato afd = new Automato();
    static public Automato afn = new Automato();
}
