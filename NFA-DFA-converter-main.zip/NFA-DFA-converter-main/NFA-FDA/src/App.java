import view.buildMenu;

public class App {
    public static void main(String[] args) throws Exception {
        //String path = "D:/Faculdade/5°periodo/Teoria da Computação/Atividades/Atividade-04/EX04Q01.jff";
        buildMenu tela = new buildMenu();
        tela.setVisible(true);
    }
}
